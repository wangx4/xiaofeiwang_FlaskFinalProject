
from baseObject import baseObject

class userFileList(baseObject):
    def __init__(self):
        self.setupObject('user_file')