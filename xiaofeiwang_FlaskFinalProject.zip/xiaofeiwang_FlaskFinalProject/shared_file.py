
from baseObject import baseObject

class sharedFileList(baseObject):
    def __init__(self):
        self.setupObject('shared_file')