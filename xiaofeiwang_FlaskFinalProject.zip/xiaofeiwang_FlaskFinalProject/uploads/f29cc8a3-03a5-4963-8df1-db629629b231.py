
from baseObject import baseObject

class fileList(baseObject):
    def __init__(self):
        self.setupObject('file')
    